package br.ulbra.provinha;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btCalcular;
    EditText edQuantidadePassos;
    CheckBox cbkSim;
    RadioGroup rgbMediaP;
    RadioButton rbtCurto, rbtMedio, rbtLongo;
    TextView txtr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
       edQuantidadePassos = findViewById(R.id.edtQuantidadePassos);
       cbkSim = findViewById(R.id.cbSim);
       rgbMediaP = findViewById(R.id.rgMediaP);
       rbtCurto = findViewById(R.id.rbCurto);
       rbtMedio = findViewById(R.id.rbMedio);
       rbtLongo = findViewById(R.id.rbLongo);
       btCalcular = findViewById(R.id.btnCalcular);
       txtr = findViewById(R.id.txtr);

       btCalcular.setOnClickListener(new View.OnClickListener() {
           @Override

           public void onClick(View view) {
               double edtQP, result;
               //
               try {
                   edtQP = Double.parseDouble(edQuantidadePassos.getText().toString());
                   //result = Double.parseDouble(txtr.getText().toString());
                   result=0;

                   int grupo = rgbMediaP.getCheckedRadioButtonId();

                   if (grupo == R.id.rbCurto) {
                       result = edtQP * 0.5;
                   } else if (grupo ==R.id.rbMedio) {
                       result = edtQP * 0.7;
                   } else if (grupo == R.id.rbLongo) {
                       result = edtQP * 1.0;
                   }

                   if(cbkSim.isChecked()) {
                       result = result+ (result* 10)/100;
                   }
                   txtr.setText("Sua distância percorrida foi: " + result + " metros");

               }catch(NumberFormatException E){
                   Toast.makeText(MainActivity.this, "Por favor, tente novamente!", Toast.LENGTH_SHORT).show();
               }
           }
       });

    }
    }
